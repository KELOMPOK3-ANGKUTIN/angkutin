
<?php
require_once "koneksi.php";

echo "Koneksi database Angkutin berhasil!";
?>
